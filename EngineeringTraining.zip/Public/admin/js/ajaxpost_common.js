//ajax提交表单数据方法
function submit_ajax_form() {
	var data=new FormData(document.form_data);
	var url=document.form_data.action;
    //console.info(document.form_data);
    //console.info(11);
	$.ajax({
		type : 'post',
		url : url,
		data : data,
		dataType : 'json',
		processData : false,
		contentType : false,
		success : function(msg) {
            //alert(data['name']);
			if (msg.status==1) {
				alert('成功添加');
			}else{
				alert('添加失败');
			}
		}

	});
}
// 点击列表的页数按钮   进行ajax的请求替换模版
$(".js-ajax-form").on("click","#page a",function(e) {
	e.preventDefault();
	var data=new FormData(document.form_data);
	$.ajax({
		url : this.href,
		type : 'post',
		data : data,
		dataType : 'json',
		processData : false,
		contentType : false,
		success : function(msg) {
			document.data_list.innerHTML=msg;	

		},

	});
});
//删除学生
function del_student(id,self) {
	// body...
	$.ajax({
		type : 'post',
		url : '/Admin/Train/ajaxDelStudent',
		data : {'id' : id},
		dataType : 'json',
		success : function(msg) {
			// body...
			if (msg.status==1) {
                self.parent().parent().remove();
			}else{
				return false;
			}
			
		}
	});
}
//删除授课
function del_train(id,self) {
	// body...
	$.ajax({
		type : 'post',
		url : '/Admin/Train/ajaxDelTrain',
		data : {'id' : id},
		dataType : 'json',
		success : function(msg) {
			// body...
			if (msg.status==1) {
                self.parent().parent().remove();
			}else{
				return false;
			}
			
		}
	});
}
//删除教师
function del_tea(id,self) {
	// body...
	$.ajax({
		type : 'post',
		url : '/Admin/Train/ajaxDelTea',
		data : {'id' : id},
		dataType : 'json',
		success : function(msg) {
			// body...
			if (msg.status==1) {
                self.parent().parent().remove();
			}else{
				return false;
			}
			
		}
	});
}
//开启签到方法
function begin_sign(id,key,val) {
	// body...
	$.ajax({
		type : 'post',
		url : '/Admin/Train/ajaxBeginSign',
		data : {'id':id,'key':key,'val':val},
		dataType : 'json',
		success : function(msg) {
			// body...
			if (msg.status==1) {
                ref_course_list();
                alert('成功');
			}else{
				alert('失败');
                return false;
			}
			
		}
	});
}
//刷新列表
function ref_course_list() {
	// body...
	var url=document.getElementById('current_url').value;
	$.ajax({
		url : url,
		type : 'post',
		// data : {'title':document.sel_article.title.value,'menu_id':document.sel_article.term.value,'start_time':document.sel_article.start_time.value,'end_time':document.sel_article.end_time.value},
		data : {'nav_id':document.data_list.value},
		success : function(msg) {
			document.data_list.innerHTML=msg;
			data_toggle_tooltip();

		},

	});
}
//已post ajax方式提交缩略图
function ajax_post_img() {
	var data=new FormData(document.getElementById('form_img'));
	$.ajax({
		type : 'POST',
		url : '/Admin/Article/uploadImg',
		data : data,
		processData : false,
		contentType : false,
		success : function(msg) {
			// body...
			// alert(msg.destination);
            var return_data=JSON.parse(msg);
			console.log(return_data);
			$("#thumb img").attr('src','/Public/common/update_img/'+return_data.uniname).css('display','block');
            
		}
	});
}
//打开上传文件的窗口
function upload_open(class_name) {
		$(class_name).css('display','block');
}
//打开图片放大的窗口
function upload_img_open(class_name,src) {
		$(class_name).css('display','block');
		$('.img_attr img').attr('src',src);
}
//关闭上传文件的窗口				
function upload_close(class_name) {
	// body...
	$(class_name).css('display','none');
}
//图片上传
function img_submit() {
	// body..
	var thumb_img=$(document.getElementById('plupload').contentWindow.document.getElementById('thumb_img')).attr("src");
	$("#thumb-preview").attr("src",thumb_img);
	$("#thumb").attr("value",thumb_img);
	$(".aui_state_lock").css("display","none");
	
}
//取消图片
function call_img(self) {
	// body...
	self.siblings('img').attr('src','/Public/common/default_img/default-thumbnail.png');
}