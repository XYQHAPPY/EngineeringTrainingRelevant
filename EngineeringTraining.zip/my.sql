/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-06-13 20:49:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `administrator`
-- ----------------------------
DROP TABLE IF EXISTS `administrator`;
CREATE TABLE `administrator` (
  `name` varchar(10) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of administrator
-- ----------------------------
INSERT INTO `administrator` VALUES ('admin', 'admin');

-- ----------------------------
-- Table structure for `qingjia`
-- ----------------------------
DROP TABLE IF EXISTS `qingjia`;
CREATE TABLE `qingjia` (
  `ID` varchar(4) NOT NULL DEFAULT '',
  `name` varchar(10) NOT NULL,
  `contents` varchar(300) CHARACTER SET utf8 NOT NULL,
  `check` varchar(1) DEFAULT '0' COMMENT '0表待审核，1表示审核通过',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of qingjia
-- ----------------------------
INSERT INTO `qingjia` VALUES ('0001', 'xiao', '请假', '0');

-- ----------------------------
-- Table structure for `shijian`
-- ----------------------------
DROP TABLE IF EXISTS `shijian`;
CREATE TABLE `shijian` (
  `id` varchar(3) DEFAULT NULL,
  `shangke` varchar(30) DEFAULT NULL,
  `xiake` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of shijian
-- ----------------------------
INSERT INTO `shijian` VALUES ('1', '2018-05-26 13:00:00', '2018-05-26 17:00:00');

-- ----------------------------
-- Table structure for `teachers`
-- ----------------------------
DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `name` varchar(10) DEFAULT NULL,
  `passwword` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of teachers
-- ----------------------------
INSERT INTO `teachers` VALUES ('teacher1', 'teacher1');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `ID` int(4) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `chidao` varchar(5) DEFAULT NULL,
  `zaotui` varchar(5) DEFAULT NULL,
  `kuangke` varchar(5) DEFAULT NULL,
  `qingjia` varchar(5) DEFAULT NULL,
  `qiandao` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('0001', 'xiao', 'xiao', '1345757', '1@qq.com', '5', '4', '8', '1', '1');
INSERT INTO `user` VALUES ('0002', 'xiao2', 'xiao2', '1543575437', 'edsrge@qq.com', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `yxblog_admin_menu`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_admin_menu`;
CREATE TABLE `yxblog_admin_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_admin_menu
-- ----------------------------
INSERT INTO `yxblog_admin_menu` VALUES ('1', '0', '设置', '');
INSERT INTO `yxblog_admin_menu` VALUES ('2', '1', '个人信息', '');
INSERT INTO `yxblog_admin_menu` VALUES ('3', '1', '网站信息', '/Admin/index/sites');
INSERT INTO `yxblog_admin_menu` VALUES ('8', '2', '修改信息', '/Admin/index/AdminUserInfo');
INSERT INTO `yxblog_admin_menu` VALUES ('9', '2', '修改密码', '/Admin/index/modiAdminPass');
INSERT INTO `yxblog_admin_menu` VALUES ('12', '0', '用户管理', '');
INSERT INTO `yxblog_admin_menu` VALUES ('13', '12', '用户列表', null);
INSERT INTO `yxblog_admin_menu` VALUES ('14', '12', '权限管理', '');
INSERT INTO `yxblog_admin_menu` VALUES ('15', '13', '本地用户', '/Admin/index/indexUserManage');
INSERT INTO `yxblog_admin_menu` VALUES ('18', '14', '操作用户', '/Admin/index/adminUserManage');
INSERT INTO `yxblog_admin_menu` VALUES ('19', '0', '内容管理', '');
INSERT INTO `yxblog_admin_menu` VALUES ('20', '19', '所有请假', '/Admin/index/leavewordManage');
INSERT INTO `yxblog_admin_menu` VALUES ('28', '0', '菜单管理', '');
INSERT INTO `yxblog_admin_menu` VALUES ('29', '28', '前台管理', null);
INSERT INTO `yxblog_admin_menu` VALUES ('30', '29', '菜单管理', '/Admin/index/indexMenuManage');
INSERT INTO `yxblog_admin_menu` VALUES ('32', '28', '后台菜单', null);
INSERT INTO `yxblog_admin_menu` VALUES ('33', '19', '请假管理', '/Admin/Index/questManage');
INSERT INTO `yxblog_admin_menu` VALUES ('34', '0', '学生签到', null);
INSERT INTO `yxblog_admin_menu` VALUES ('35', '34', '签到信息', '');
INSERT INTO `yxblog_admin_menu` VALUES ('36', '35', '签到信息', '/Admin/Index/signManage');
INSERT INTO `yxblog_admin_menu` VALUES ('40', '0', '信息管理', null);
INSERT INTO `yxblog_admin_menu` VALUES ('41', '40', '学生信息管理', '/Admin/index/trainStudentManage');
INSERT INTO `yxblog_admin_menu` VALUES ('42', '40', '授课信息管理', '/Admin/index/trainCourseManage');
INSERT INTO `yxblog_admin_menu` VALUES ('43', '40', '老师信息管理', '/Admin/index/trainTeaManage');
INSERT INTO `yxblog_admin_menu` VALUES ('44', '40', '教室信息管理', '/Admin/index/trainRoomManage');
INSERT INTO `yxblog_admin_menu` VALUES ('45', '40', '班级信息', '/Admin/index/trainBeginsManage');

-- ----------------------------
-- Table structure for `yxblog_admin_user`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_admin_user`;
CREATE TABLE `yxblog_admin_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `exa_juris` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_admin_user
-- ----------------------------
INSERT INTO `yxblog_admin_user` VALUES ('1', 'admin', '13f863492f2b6cff28a797690d8fa5e7', 'admin', '1,2,8,9,3,12,13,15,14,18,19,20,22,33,28,29,30,32,34,35,36,37,38,39,40,41,42,43,44,45');
INSERT INTO `yxblog_admin_user` VALUES ('2', 'teacher', '13f863492f2b6cff28a797690d8fa5e7', 'teacher', '1,2,8,9,3,19,20,33,28,29,30,32,34,35,36,40,41,42');
INSERT INTO `yxblog_admin_user` VALUES ('3', 'student', '13f863492f2b6cff28a797690d8fa5e7', 'student', '1,2,8,9,3,19,20,34,35,36');

-- ----------------------------
-- Table structure for `yxblog_admin_user_info`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_admin_user_info`;
CREATE TABLE `yxblog_admin_user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` char(128) NOT NULL,
  `phone` char(128) NOT NULL,
  `birth` char(128) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_admin_user_info
-- ----------------------------
INSERT INTO `yxblog_admin_user_info` VALUES ('1', '', '13735450432', '882028800', '1');
INSERT INTO `yxblog_admin_user_info` VALUES ('2', '', '', '', '13');
INSERT INTO `yxblog_admin_user_info` VALUES ('3', '', '', '', '16');
INSERT INTO `yxblog_admin_user_info` VALUES ('4', '', '', '', '17');
INSERT INTO `yxblog_admin_user_info` VALUES ('5', '', '', '', '18');

-- ----------------------------
-- Table structure for `yxblog_admin_user_record`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_admin_user_record`;
CREATE TABLE `yxblog_admin_user_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` char(32) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_admin_user_record
-- ----------------------------
INSERT INTO `yxblog_admin_user_record` VALUES ('1', 'is2kmt1s5pn0hjrgl619tp9pq6', '1');
INSERT INTO `yxblog_admin_user_record` VALUES ('2', 'jvcsigjt2b8d3c51lek5hjvkj0', '3');
INSERT INTO `yxblog_admin_user_record` VALUES ('3', 'lnlkormemlktnkcp51dt539bp4', '16');
INSERT INTO `yxblog_admin_user_record` VALUES ('4', 'rq1l6upgs9bqep5p1ehn', '2');
INSERT INTO `yxblog_admin_user_record` VALUES ('5', '06gl9n4ohuj3u5k6s51r2fd680', '18');

-- ----------------------------
-- Table structure for `yxblog_college_area`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_college_area`;
CREATE TABLE `yxblog_college_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of yxblog_college_area
-- ----------------------------
INSERT INTO `yxblog_college_area` VALUES ('1', '北京');
INSERT INTO `yxblog_college_area` VALUES ('2', '上海');
INSERT INTO `yxblog_college_area` VALUES ('3', '天津');
INSERT INTO `yxblog_college_area` VALUES ('4', '重庆');
INSERT INTO `yxblog_college_area` VALUES ('5', '黑龙江');
INSERT INTO `yxblog_college_area` VALUES ('6', '吉林');
INSERT INTO `yxblog_college_area` VALUES ('7', '辽宁');
INSERT INTO `yxblog_college_area` VALUES ('8', '山东');
INSERT INTO `yxblog_college_area` VALUES ('9', '山西');
INSERT INTO `yxblog_college_area` VALUES ('10', '陕西');
INSERT INTO `yxblog_college_area` VALUES ('11', '河北');
INSERT INTO `yxblog_college_area` VALUES ('12', '河南');
INSERT INTO `yxblog_college_area` VALUES ('13', '湖北');
INSERT INTO `yxblog_college_area` VALUES ('14', '湖南');
INSERT INTO `yxblog_college_area` VALUES ('15', '海南');
INSERT INTO `yxblog_college_area` VALUES ('16', '江苏');
INSERT INTO `yxblog_college_area` VALUES ('17', '江西');
INSERT INTO `yxblog_college_area` VALUES ('18', '广东');
INSERT INTO `yxblog_college_area` VALUES ('19', '广西');
INSERT INTO `yxblog_college_area` VALUES ('20', '云南');
INSERT INTO `yxblog_college_area` VALUES ('21', '贵州');
INSERT INTO `yxblog_college_area` VALUES ('22', '四川');
INSERT INTO `yxblog_college_area` VALUES ('23', '内蒙古');
INSERT INTO `yxblog_college_area` VALUES ('24', '宁夏');
INSERT INTO `yxblog_college_area` VALUES ('25', '甘肃');
INSERT INTO `yxblog_college_area` VALUES ('26', '青海');
INSERT INTO `yxblog_college_area` VALUES ('27', '西藏');
INSERT INTO `yxblog_college_area` VALUES ('28', '新疆');
INSERT INTO `yxblog_college_area` VALUES ('29', '安徽');
INSERT INTO `yxblog_college_area` VALUES ('30', '浙江');
INSERT INTO `yxblog_college_area` VALUES ('31', '福建');
INSERT INTO `yxblog_college_area` VALUES ('32', '台湾');
INSERT INTO `yxblog_college_area` VALUES ('33', '香港');
INSERT INTO `yxblog_college_area` VALUES ('34', '澳门');
INSERT INTO `yxblog_college_area` VALUES ('35', '国外');

-- ----------------------------
-- Table structure for `yxblog_index_menu`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_index_menu`;
CREATE TABLE `yxblog_index_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL,
  `menu_name` varchar(50) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_index_menu
-- ----------------------------
INSERT INTO `yxblog_index_menu` VALUES ('2', '0', 'Blog', null);
INSERT INTO `yxblog_index_menu` VALUES ('3', '2', 'HOME', null);
INSERT INTO `yxblog_index_menu` VALUES ('4', '2', 'PHP', null);
INSERT INTO `yxblog_index_menu` VALUES ('5', '2', 'ESSAYS', null);
INSERT INTO `yxblog_index_menu` VALUES ('9', '2', 'MAIN WEBSITE', null);
INSERT INTO `yxblog_index_menu` VALUES ('6', '2', 'javascript', null);
INSERT INTO `yxblog_index_menu` VALUES ('18', '2', 'java', 'http://');

-- ----------------------------
-- Table structure for `yxblog_index_user`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_index_user`;
CREATE TABLE `yxblog_index_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `pet_name` varchar(255) NOT NULL,
  `portrait` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `regi_time` varchar(255) NOT NULL,
  `login_time` varchar(255) NOT NULL,
  `login_ip` varchar(255) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_index_user
-- ----------------------------
INSERT INTO `yxblog_index_user` VALUES ('1', 'student', '123456', '匿名', '', 'rcyunchina@163.com', '', '', '', '1');
INSERT INTO `yxblog_index_user` VALUES ('3', 'teacher', '123456', '', '', '', '', '', '', '1');

-- ----------------------------
-- Table structure for `yxblog_leave_word`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_leave_word`;
CREATE TABLE `yxblog_leave_word` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `u_id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_leave_word
-- ----------------------------
INSERT INTO `yxblog_leave_word` VALUES ('1', '1', 'shd', 'sdhgh', '1484031543', '0');
INSERT INTO `yxblog_leave_word` VALUES ('2', '1', 'gasdg', '5156', '1484031543', '1');
INSERT INTO `yxblog_leave_word` VALUES ('10', '1', '564465', '8546', '1484031543', '0');
INSERT INTO `yxblog_leave_word` VALUES ('14', '1', '561', '156', '1484031543', '0');
INSERT INTO `yxblog_leave_word` VALUES ('15', '1', '561', '65465', '1484031543', '1');

-- ----------------------------
-- Table structure for `yxblog_quest`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_quest`;
CREATE TABLE `yxblog_quest` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `send_name` varchar(255) NOT NULL,
  `send_content` varchar(255) NOT NULL,
  `send_datetime` varchar(255) NOT NULL,
  `put_name` varchar(255) NOT NULL,
  `put_content` varchar(255) NOT NULL,
  `put_datetime` varchar(255) NOT NULL,
  `status` int(10) NOT NULL,
  `n_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3246 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_quest
-- ----------------------------
INSERT INTO `yxblog_quest` VALUES ('2', 'jasihj将噶克里斯', '据阿里可根据', '1484104587', '', '阿斯尽快回归', '', '1', '1');

-- ----------------------------
-- Table structure for `yxblog_sign_info`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_sign_info`;
CREATE TABLE `yxblog_sign_info` (
  `ID` int(4) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `chidao` varchar(5) DEFAULT NULL,
  `zaotui` varchar(5) DEFAULT NULL,
  `kuangke` varchar(5) DEFAULT NULL,
  `qingjia` varchar(5) DEFAULT NULL,
  `qiandao` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of yxblog_sign_info
-- ----------------------------
INSERT INTO `yxblog_sign_info` VALUES ('0001', 'xiao', 'xiao', '1345757', '1@qq.com', '5', '4', '7', '1', '1');
INSERT INTO `yxblog_sign_info` VALUES ('0002', 'xiao2', 'xiao2', '1543575437', 'edsrge@qq.com', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `yxblog_sites`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_sites`;
CREATE TABLE `yxblog_sites` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(255) NOT NULL,
  `site_admin_email` varchar(255) NOT NULL,
  `site_statistics` mediumtext NOT NULL,
  `site_copyright` varchar(255) NOT NULL,
  `site_icp` varchar(255) NOT NULL,
  `site_links` varchar(255) NOT NULL,
  `site_seo_title` varchar(255) NOT NULL,
  `site_seo_keywords` varchar(255) NOT NULL,
  `site_seo_description` varchar(255) NOT NULL,
  `site_admin_qq` varchar(255) NOT NULL,
  `site_admin_sina_weibo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_sites
-- ----------------------------
INSERT INTO `yxblog_sites` VALUES ('1', '学生考勤系统', 'xxx@163.com', '&lt;!--百度验证代码--&gt;\r\n&lt;meta name=&quot;baidu-site-verification&quot; content=&quot;YpTMrQ4rcn&quot; /&gt;\r\n&lt;!--百度验证代码--&gt;\r\n&lt;!--百度统计代码--&gt;\r\n&lt;script&gt;\r\nvar _hmt = _hmt || [];\r\n(function() {\r\n  var hm = document.createElement(&quot;script&quot;);\r\n  hm.src = &quot;https://hm.baidu.com/hm.js?d69808f83b66ddc58bc8e5dab24263da&quot;;\r\n  var s = document.getElementsByTagName(&quot;script&quot;)[0]; \r\n  s.parentNode.insertBefore(hm, s);\r\n})();\r\n&lt;/script&gt;\r\n&lt;!--百度统计代码--&gt;\r\n&lt;!--百度自动推送代码--&gt;\r\n&lt;script&gt;\r\n(function(){\r\n    var bp = document.createElement(\'script\');\r\n    var curProtocol = window.location.protocol.split(\':\')[0];\r\n    if (curProtocol === \'https\') {\r\n        bp.src = \'https://zz.bdstatic.com/linksubmit/push.js\';        \r\n    }\r\n    else {\r\n        bp.src = \'http://push.zhanzhang.baidu.com/push.js\';\r\n    }\r\n    var s = document.getElementsByTagName(&quot;script&quot;)[0];\r\n    s.parentNode.insertBefore(bp, s);\r\n})();\r\n&lt;/script&gt;\r\n&lt;!--百度自动推送代码--&gt;', 'Copyright © 2018 All Right', '京ICP备17006号-3', 'www.xxxxxxx.com', '学生考勤系统', 'ThinkPHP,PHP,JAVASCRIPT,laravel,ysxk,软件,网站,夜色星空,夜星,夜星工作室,97云,97云分享,97云资源,97yun,97', '学生考勤系统', '18259526', 'www.xxxxxxxx.com');

-- ----------------------------
-- Table structure for `yxblog_train_begins`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_train_begins`;
CREATE TABLE `yxblog_train_begins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `c_id` int(11) NOT NULL,
  `t_id` int(11) NOT NULL,
  `r_id` int(11) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `ramark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_train_begins
-- ----------------------------
INSERT INTO `yxblog_train_begins` VALUES ('1', 'java', '3', '2', '3', '345632456543', '飞洒啊');
INSERT INTO `yxblog_train_begins` VALUES ('2', 'php', '3', '2', '3', '2017-3-2', '阿斯各');
INSERT INTO `yxblog_train_begins` VALUES ('3', '张', '1', '2', '4', '1489381178', '');

-- ----------------------------
-- Table structure for `yxblog_train_course`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_train_course`;
CREATE TABLE `yxblog_train_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `ramark` varchar(255) NOT NULL,
  `classroom` varchar(10) NOT NULL,
  `time` varchar(50) NOT NULL,
  `sign_range` varchar(10) NOT NULL,
  `begin_sign_tag` varchar(1) NOT NULL DEFAULT '0' COMMENT '1表示开启签到，0表示未开启签到',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_train_course
-- ----------------------------
INSERT INTO `yxblog_train_course` VALUES ('1', '舞蹈室', '金刚萨洛克几个啦', '#32-123', '(2018-05-26 13:00:00~2018-05-26 17:00:00)', '10米', '0');
INSERT INTO `yxblog_train_course` VALUES ('13', 'saefsearg', 'dsfhgsdr', '', '', '', '1');

-- ----------------------------
-- Table structure for `yxblog_train_room`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_train_room`;
CREATE TABLE `yxblog_train_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `ramark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_train_room
-- ----------------------------
INSERT INTO `yxblog_train_room` VALUES ('1', '舞蹈室', '金刚萨洛克几个啦');
INSERT INTO `yxblog_train_room` VALUES ('3', '办公室', '');
INSERT INTO `yxblog_train_room` VALUES ('4', '舞蹈教室1', '');

-- ----------------------------
-- Table structure for `yxblog_train_student`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_train_student`;
CREATE TABLE `yxblog_train_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sex` varchar(11) NOT NULL,
  `birth` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `site` varchar(255) NOT NULL,
  `ramark` varchar(255) NOT NULL,
  `money` int(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `b_id` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_train_student
-- ----------------------------
INSERT INTO `yxblog_train_student` VALUES ('1', '匿名', '男', '882028800', '13735450432', '北京', '啊噶时光', '啊杀啥', '50000', '1', '1', '/Public/common/update_img/20170312/cf17ae1e95c58da4b7cec8455a1550a2.png');
INSERT INTO `yxblog_train_student` VALUES ('3', '匿名', '男', '1488816000', '15699992858', '立刻大师傅', '地方', '', '0', '1', '1', '/Public/common/default_img/default-thumbnail.png');

-- ----------------------------
-- Table structure for `yxblog_train_tea`
-- ----------------------------
DROP TABLE IF EXISTS `yxblog_train_tea`;
CREATE TABLE `yxblog_train_tea` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sex` char(10) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `wechat` varchar(255) NOT NULL,
  `rank` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yxblog_train_tea
-- ----------------------------
INSERT INTO `yxblog_train_tea` VALUES ('1', '发撒法', '男', '12132', '13123', '232', '/Public/common/update_img/20170312/97520c451e2196908156c1487a05203b.jpg');
INSERT INTO `yxblog_train_tea` VALUES ('2', '匿名', '男', '', '', '', '/Public/common/default_img/default-thumbnail.png');
INSERT INTO `yxblog_train_tea` VALUES ('3', 'xyq', '男', '3452345', '4遏624完', '二', '/Public/common/default_img/default-thumbnail.png');
INSERT INTO `yxblog_train_tea` VALUES ('4', 'dargshf', '男', 'dfg', 'sdgh', 'sdghsd', '/Public/common/default_img/default-thumbnail.png');
